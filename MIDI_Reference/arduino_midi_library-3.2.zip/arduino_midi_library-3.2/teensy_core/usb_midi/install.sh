cp *.cpp /Applications/Arduino.app/Contents/Resources/Java/hardware/teensy/cores/usb_midi/
cp *.c /Applications/Arduino.app/Contents/Resources/Java/hardware/teensy/cores/usb_midi/
cp *.h /Applications/Arduino.app/Contents/Resources/Java/hardware/teensy/cores/usb_midi/