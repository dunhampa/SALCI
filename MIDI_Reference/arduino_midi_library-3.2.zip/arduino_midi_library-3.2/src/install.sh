cp ./MIDI.* /Applications/Arduino.app/Contents/Resources/Java/libraries/MIDI 
cd teensy_core/usb_midi
./install.sh